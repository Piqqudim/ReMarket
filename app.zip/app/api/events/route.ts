import {
  NextRequest,
  NextResponse,
} from "next/server";

import { prisma } from "@/lib/prisma";

const ALLOWED_PLATFORMS = [
  "WHATSAPP",
  "INSTAGRAM",
  "TIKTOK",
  "FACEBOOK",
  "PHONE",
  "DIRECTIONS",
] as const;

type ContactPlatform =
  (typeof ALLOWED_PLATFORMS)[number];

function isRecord(
  value: unknown
): value is Record<string, unknown> {
  return (
    typeof value === "object" &&
    value !== null &&
    !Array.isArray(value)
  );
}

export async function POST(
  req: NextRequest
) {
  try {
    /*
     * -----------------------------------------
     * PARSE REQUEST BODY
     * -----------------------------------------
     */

    let body: unknown;

    try {
      body = await req.json();
    } catch {
      return NextResponse.json(
        {
          error: "Invalid JSON body",
        },
        {
          status: 400,
        }
      );
    }

    if (!isRecord(body)) {
      return NextResponse.json(
        {
          error: "Invalid request body",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * -----------------------------------------
     * READ FIELDS
     * -----------------------------------------
     */

    const businessId =
      typeof body.businessId === "string"
        ? body.businessId.trim()
        : "";

    const requestId =
      typeof body.requestId === "string"
        ? body.requestId.trim() || null
        : null;

    const platform =
      typeof body.platform === "string"
        ? body.platform.trim().toUpperCase()
        : "";

    /*
     * -----------------------------------------
     * VALIDATE REQUIRED FIELDS
     * -----------------------------------------
     */

    if (!businessId || !platform) {
      return NextResponse.json(
        {
          error:
            "businessId and platform are required",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * -----------------------------------------
     * VALIDATE PLATFORM
     * -----------------------------------------
     */

    if (
      !ALLOWED_PLATFORMS.includes(
        platform as ContactPlatform
      )
    ) {
      return NextResponse.json(
        {
          error: "Invalid platform",
        },
        {
          status: 400,
        }
      );
    }

    /*
     * -----------------------------------------
     * VERIFY BUSINESS
     * -----------------------------------------
     *
     * Only active, non-soft-deleted businesses
     * may receive contact events.
     */

    const business =
      await prisma.business.findFirst({
        where: {
          id: businessId,
          status: "ACTIVE",
          deletedAt: null,
        },
        select: {
          id: true,
        },
      });

    if (!business) {
      return NextResponse.json(
        {
          error: "Business not found",
        },
        {
          status: 404,
        }
      );
    }

    /*
     * -----------------------------------------
     * VERIFY REQUEST WHEN PROVIDED
     * -----------------------------------------
     */

    if (requestId) {
      const buyerRequest =
        await prisma.buyerRequest.findUnique({
          where: {
            id: requestId,
          },
          select: {
            id: true,
          },
        });

      if (!buyerRequest) {
        return NextResponse.json(
          {
            error: "Request not found",
          },
          {
            status: 404,
          }
        );
      }
    }

    /*
     * -----------------------------------------
     * CREATE CONTACT EVENT
     * -----------------------------------------
     */

    const event =
      await prisma.contactEvent.create({
        data: {
          businessId,
          requestId,
          platform:
            platform as ContactPlatform,
        },
        select: {
          id: true,
          businessId: true,
          requestId: true,
          platform: true,
          createdAt: true,
        },
      });

    /*
     * -----------------------------------------
     * SUCCESS
     * -----------------------------------------
     */

    return NextResponse.json(
      {
        success: true,
        event,
      },
      {
        status: 201,
      }
    );
  } catch (error) {
    console.error(
      "Contact event error:",
      error
    );

    return NextResponse.json(
      {
        error:
          "Unable to record contact event",
      },
      {
        status: 500,
      }
    );
  }
}