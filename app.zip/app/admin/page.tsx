
"use client";

import Link from "next/link";

import {
  ArrowRight,
  ClipboardList,
  Contact,
  LayoutDashboard,
  MapPin,
  Megaphone,
  Package,
  Phone,
  Store,
  Trash2,
  Users,
  ExternalLink,
  UserRound,
  Tags,
  Eye,
  AlertCircle,
  LogOut,
  ChevronLeft,
  ChevronRight,
  RefreshCw,
  CalendarDays,
} from "lucide-react";

import {
  useEffect,
  useState,
} from "react";

import {
  usePathname,
} from "next/navigation";

import {
  signOut,
} from "next-auth/react";

import NotificationBell from "@/components/NotificationBell";

type ContactActivity = {
  WHATSAPP: number;
  PHONE: number;
  INSTAGRAM: number;
  TIKTOK: number;
  FACEBOOK: number;
  DIRECTIONS: number;
};

const DEFAULT_CONTACT_ACTIVITY: ContactActivity = {
  WHATSAPP: 0,
  PHONE: 0,
  INSTAGRAM: 0,
  TIKTOK: 0,
  FACEBOOK: 0,
  DIRECTIONS: 0,
};

type Overview = {
  stats: {
    businesses: number;
    products: number;
    requests: number;
    matches: number;
    contacts: number;
    businessViews: number;
  };

  operations: {
    sellerAccounts: number;
    pendingDeletionRequests: number;
    pendingClaimRequests: number;
    categories: number;
    activeCategories: number;
  };

  contactActivity: ContactActivity;

  recentRequests: {
    id: string;
    requestCode: string;
    query: string;
    status: string;
    category?: {
      id: string;
      name: string;
    } | null;
    createdAt: string;
    matchCount: number;
  }[];

  recentBusinesses: {
    id: string;
    name: string;
    verification: string;
    status: string;
    availability?: string | null;
    area: string | null;
    onboardedAt: string;
  }[];
};

type RegisteredBusiness = {
  id: string;
  name: string;
  verification: string;
  status: string;
  availability?: string | null;
  area: string | null;
  onboardedAt: string;
  deletedAt: string | null;
};

const REGISTERED_BUSINESSES_PAGE_SIZE = 6;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizeRegisteredBusiness(value: unknown): RegisteredBusiness | null {
  if (!isRecord(value)) return null;

  const id = value.id;
  const name = value.name;
  const status = value.status;
  const verification = value.verification;

  const onboardedAt =
    typeof value.onboardedAt === "string"
      ? value.onboardedAt
      : typeof value.createdAt === "string"
        ? value.createdAt
        : null;

  if (
    typeof id !== "string" ||
    typeof name !== "string" ||
    typeof status !== "string" ||
    typeof verification !== "string" ||
    onboardedAt === null
  ) {
    return null;
  }

  return {
    id,
    name,
    status,
    verification,
    availability:
      typeof value.availability === "string"
        ? value.availability
        : null,
    area:
      typeof value.area === "string"
        ? value.area
        : isRecord(value.location) &&
            typeof value.location.area === "string"
          ? value.location.area
          : null,
    onboardedAt,
    deletedAt:
      typeof value.deletedAt === "string"
        ? value.deletedAt
        : null,
  };
}

function businessStatusClass(status: string): string {
  switch (status) {
    case "ACTIVE":
      return "bg-[#E7F7EF] text-[#287A4B]";

    case "PENDING":
      return "bg-[#FFF0D9] text-[#9F5A18]";

    case "INACTIVE":
      return "bg-[#F0ECE7] text-[#6F675F]";

    default:
      return "bg-[#F0ECE7] text-[#6F675F]";
  }
}

const ADMIN_NAV = [
  {
    label: "Overview",
    href: "/admin",
    icon: LayoutDashboard,
  },
  {
    label: "Businesses",
    href: "/admin/businesses",
    icon: Store,
  },
  {
    label: "Products",
    href: "/admin/products",
    icon: Package,
  },
  {
    label: "Service bookings",
    href: "/admin/bookings",
    icon: CalendarDays,
  },
  {
    label: "Requests",
    href: "/admin/requests",
    icon: ClipboardList,
  },
  {
    label: "Content",
    href: "/admin/content",
    icon: Megaphone,
  },
  {
    label: "Claims",
    href: "/admin/claims",
    icon: UserRound,
  },
  {
    label: "Deletion requests",
    href: "/admin/business-deletion-requests",
    icon: Trash2,
  },
];

function formatDate(value: string) {
  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "Date unavailable";
  }

  return date.toLocaleDateString("en-NG", {
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

function statusClass(status: string) {
  switch (status) {
    case "MATCHED":
      return "bg-[#E7F7EF] text-[#287A4B]";

    case "FULFILLED":
      return "bg-[#E7F7EF] text-[#287A4B]";

    case "CLOSED":
      return "bg-[#F0ECE7] text-[#6F675F]";

    case "CONTACTED":
      return "bg-[#FFF0D9] text-[#9F5A18]";

    default:
      return "bg-[#FFF0D9] text-[#9F5A18]";
  }
}

function verificationClass(verification: string) {
  switch (verification) {
    case "VERIFIED":
      return "bg-[#E7F7EF] text-[#287A4B]";

    case "PENDING":
      return "bg-[#FFF0D9] text-[#9F5A18]";

    case "REJECTED":
      return "bg-[#FCE8E6] text-[#B42318]";

    default:
      return "bg-[#F0ECE7] text-[#6F675F]";
  }
}

function ContactActivityCard({
  label,
  value,
  icon: Icon,
}: {
  label: string;
  value: number;
  icon: typeof Contact;
}) {
  return (
    <div className="rounded-2xl border border-[#E8DED3] bg-white p-5">
      <div className="flex items-center justify-between">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#FFF0E8] text-[#9F2D18]">
          <Icon className="h-5 w-5" />
        </div>

        <span className="text-2xl font-semibold text-[#2E241F]">
          {value}
        </span>
      </div>

      <p className="mt-4 text-sm font-medium text-[#6F675F]">
        {label}
      </p>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon: Icon,
  href,
}: {
  label: string;
  value: number;
  icon: typeof Store;
  href?: string;
}) {
  const content = (
    <div className="rounded-2xl border border-[#E8DED3] bg-white p-5 transition hover:border-[#D8C9BC]">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-[#6F675F]">
            {label}
          </p>

          <p className="mt-2 text-3xl font-semibold tracking-tight text-[#2E241F]">
            {value}
          </p>
        </div>

        <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-[#FFF0E8] text-[#9F2D18]">
          <Icon className="h-5 w-5" />
        </div>
      </div>

      {href && (
        <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#9F2D18]">
          View details
          <ArrowRight className="h-3.5 w-3.5" />
        </div>
      )}
    </div>
  );

  if (!href) {
    return content;
  }

  return (
    <Link href={href}>
      {content}
    </Link>
  );
}

function OperationCard({
  label,
  value,
  description,
  icon: Icon,
  href,
  attention = false,
}: {
  label: string;
  value: number;
  description: string;
  icon: typeof Store;
  href?: string;
  attention?: boolean;
}) {
  const content = (
    <div
      className={`rounded-2xl border bg-white p-5 transition ${
        attention
          ? "border-[#F1D1C9]"
          : "border-[#E8DED3]"
      } ${
        href
          ? "hover:border-[#D8C9BC]"
          : ""
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-sm font-medium text-[#6F675F]">
            {label}
          </p>

          <p className="mt-2 text-3xl font-semibold tracking-tight text-[#2E241F]">
            {value}
          </p>

          <p className="mt-2 text-xs leading-5 text-[#8B8178]">
            {description}
          </p>
        </div>

        <div
          className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl ${
            attention
              ? "bg-[#FFF0E8] text-[#9F2D18]"
              : "bg-[#F7F1EB] text-[#6F675F]"
          }`}
        >
          <Icon className="h-5 w-5" />
        </div>
      </div>

      {href && (
        <div className="mt-4 flex items-center gap-1 text-xs font-medium text-[#9F2D18]">
          View details
          <ArrowRight className="h-3.5 w-3.5" />
        </div>
      )}
    </div>
  );

  if (!href) {
    return content;
  }

  return (
    <Link href={href}>
      {content}
    </Link>
  );
}

export default function AdminPage() {
  const pathname = usePathname();

  const [data, setData] = useState<Overview | null>(null);

  const [contactActivity, setContactActivity] =
    useState<ContactActivity>(DEFAULT_CONTACT_ACTIVITY);

  const [loading, setLoading] = useState(true);

  const [error, setError] = useState("");

  const [registeredBusinesses, setRegisteredBusinesses] =
    useState<RegisteredBusiness[]>([]);

  const [businessDirectoryLoading, setBusinessDirectoryLoading] =
    useState(true);

  const [businessDirectoryError, setBusinessDirectoryError] =
    useState("");

  const [businessPage, setBusinessPage] = useState(1);

  const [businessDirectoryTotal, setBusinessDirectoryTotal] =
    useState(0);

  const [businessDirectoryTotalPages, setBusinessDirectoryTotalPages] =
    useState(0);

  const [businessReloadKey, setBusinessReloadKey] = useState(0);

  async function handleLogout() {
    try {
      await signOut({
        callbackUrl: "/admin/login",
      });
    } catch (logoutError) {
      console.error(
        "Admin logout error:",
        logoutError
      );
    }
  }

  /*
   * -------------------------------------------------------
   * LOAD ADMIN OVERVIEW
   * -------------------------------------------------------
   */

  useEffect(() => {
    let cancelled = false;

    async function loadOverview() {
      try {
        setLoading(true);
        setError("");

        const response = await fetch(
          "/api/admin/overview",
          {
            cache: "no-store",
          }
        );

        if (!response.ok) {
          const body = await response.text();

          console.error(
            "Admin overview request failed:",
            response.status,
            body
          );

          throw new Error(
            `Admin overview failed (${response.status}): ${body}`
          );
        }

        const result: Overview = await response.json();

        if (cancelled) {
          return;
        }

        setData(result);

        setContactActivity(
          result.contactActivity ??
            DEFAULT_CONTACT_ACTIVITY
        );
      } catch (error) {
        console.error(error);

        if (!cancelled) {
          setError(
            "We couldn't load the admin dashboard."
          );
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadOverview();

    return () => {
      cancelled = true;
    };
  }, []);

  /*
   * -------------------------------------------------------
   * LOAD REGISTERED BUSINESSES
   * -------------------------------------------------------
   */

  useEffect(() => {
    let cancelled = false;

    const controller = new AbortController();

    async function loadRegisteredBusinesses() {
      setBusinessDirectoryLoading(true);
      setBusinessDirectoryError("");

      try {
        const params = new URLSearchParams({
          deleted: "ALL",
          page: String(businessPage),
          pageSize: String(REGISTERED_BUSINESSES_PAGE_SIZE),
          sort: "onboardedAt",
        });

        const response = await fetch(
          `/api/admin/businesses?${params.toString()}`,
          {
            method: "GET",
            cache: "no-store",
            signal: controller.signal,
          }
        );

        const result: unknown = await response.json().catch(() => null);

        if (!response.ok) {
          const message =
            isRecord(result) && typeof result.error === "string"
              ? result.error
              : "Unable to load registered businesses.";

          throw new Error(message);
        }

        if (
          !isRecord(result) ||
          !Array.isArray(result.businesses) ||
          !isRecord(result.pagination)
        ) {
          throw new Error(
            "The registered-business response did not include valid pagination information."
          );
        }

        const pagination = result.pagination;

        if (
          typeof pagination.page !== "number" ||
          typeof pagination.total !== "number" ||
          typeof pagination.totalPages !== "number" ||
          !Number.isInteger(pagination.page) ||
          !Number.isInteger(pagination.total) ||
          !Number.isInteger(pagination.totalPages) ||
          pagination.total < 0 ||
          pagination.totalPages < 0
        ) {
          throw new Error(
            "The registered-business pagination response was invalid."
          );
        }

        const businesses = result.businesses
          .map(normalizeRegisteredBusiness)
          .filter(
            (business): business is RegisteredBusiness =>
              business !== null
          );

        if (cancelled) return;

        setRegisteredBusinesses(businesses);
        setBusinessDirectoryTotal(pagination.total);
        setBusinessDirectoryTotalPages(pagination.totalPages);

        // If the directory shrank while on a later page, return to a valid page.
        if (
          pagination.totalPages > 0 &&
          businessPage > pagination.totalPages
        ) {
          setBusinessPage(pagination.totalPages);
        } else if (
          pagination.totalPages === 0 &&
          businessPage !== 1
        ) {
          setBusinessPage(1);
        }
      } catch (loadError) {
        if (controller.signal.aborted) return;

        console.error(
          "Load registered businesses error:",
          loadError
        );

        if (!cancelled) {
          setRegisteredBusinesses([]);
          setBusinessDirectoryTotal(0);
          setBusinessDirectoryTotalPages(0);

          setBusinessDirectoryError(
            loadError instanceof Error
              ? loadError.message
              : "We couldn't load registered businesses."
          );
        }
      } finally {
        if (!cancelled) {
          setBusinessDirectoryLoading(false);
        }
      }
    }

    void loadRegisteredBusinesses();

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [businessReloadKey, businessPage]);

  /*
   * -------------------------------------------------------
   * REGISTERED BUSINESS PAGINATION
   * -------------------------------------------------------
   */

  const businessTotalPages = Math.max(
    1,
    businessDirectoryTotalPages
  );

  const safeBusinessPage = Math.min(
    businessPage,
    businessTotalPages
  );

  const businessStartIndex =
    businessDirectoryTotal === 0
      ? 0
      : (safeBusinessPage - 1) *
        REGISTERED_BUSINESSES_PAGE_SIZE;

  const businessEndIndex = Math.min(
    safeBusinessPage *
      REGISTERED_BUSINESSES_PAGE_SIZE,
    businessDirectoryTotal
  );

  const pagedRegisteredBusinesses = registeredBusinesses;

  /*
   * -------------------------------------------------------
   * RENDER
   * -------------------------------------------------------
   */

  return (
    <div className="min-h-dvh w-full overflow-x-hidden bg-[#FAF6EF] text-[#2E241F]">
      <div className="flex min-h-dvh w-full">

        {/* =================================================
            DESKTOP SIDEBAR
        ================================================= */}

        <aside className="hidden w-64 shrink-0 border-r border-[#E8DED3] bg-[#FFFDFC] lg:block">
          <div className="sticky top-0 flex h-dvh flex-col">

            <div className="border-b border-[#E8DED3] px-6 py-6">
              <Link
                href="/admin"
                className="flex items-center gap-3"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#9F2D18] text-sm font-bold text-white">
                  R
                </div>

                <div>
                  <p className="font-semibold text-[#2E241F]">
                    ReMarket
                  </p>

                  <p className="text-xs text-[#8B8178]">
                    Admin
                  </p>
                </div>
              </Link>
            </div>

            <nav className="flex-1 px-4 py-6">
              <p className="mb-3 px-3 text-[11px] font-semibold uppercase tracking-wider text-[#9A9087]">
                Dashboard
              </p>

              <div className="space-y-1">
                {ADMIN_NAV.map((item) => {
                  const Icon = item.icon;

                  const active =
                    item.href === "/admin"
                      ? pathname === "/admin"
                      : pathname === item.href ||
                        pathname.startsWith(
                          `${item.href}/`
                        );

                  return (
                    <Link
                      key={item.href}
                      href={item.href}
                      className={`flex items-center gap-3 rounded-xl px-3 py-3 text-sm font-medium transition ${
                        active
                          ? "bg-[#FFF0E8] text-[#9F2D18]"
                          : "text-[#6F675F] hover:bg-[#F7F1EB] hover:text-[#2E241F]"
                      }`}
                    >
                      <Icon className="h-4 w-4" />

                      <span>{item.label}</span>
                    </Link>
                  );
                })}
              </div>
            </nav>

            {/* Admin footer + logout */}

            <div className="border-t border-[#E8DED3] px-4 py-4">
              <div className="mb-4 px-2">
                <p className="text-xs text-[#9A9087]">
                  ReMarket Admin
                </p>

                <p className="mt-1 text-sm font-medium text-[#4B4038]">
                  Platform overview
                </p>
              </div>

              <button
                type="button"
                onClick={() => void handleLogout()}
                className="
                  flex
                  w-full
                  items-center
                  gap-3
                  rounded-xl
                  px-3
                  py-3
                  text-left
                  text-sm
                  font-medium
                  text-[#9F2D18]
                  transition
                  hover:bg-[#FFF0E8]
                "
              >
                <LogOut className="h-4 w-4" />

                <span>Log out</span>
              </button>
            </div>
          </div>
        </aside>

        {/* =================================================
            MAIN CONTENT
        ================================================= */}

        <main className="min-w-0 flex-1">
          <div className="mx-auto w-full max-w-7xl px-3 pt-5 pb-36 sm:px-6 sm:pt-6 lg:px-8 lg:py-8 lg:pb-8">

            {/* HEADER */}

            <div className="mb-8">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-sm font-medium text-[#9F2D18]">
                    Admin Dashboard
                  </p>

                  <h1 className="mt-1 text-2xl font-semibold tracking-tight text-[#2E241F] sm:text-3xl">
                    Overview
                  </h1>

                  <p className="mt-2 max-w-2xl text-sm leading-6 text-[#766C63]">
                    Monitor businesses,
                    products,
                    buyer requests,
                    matches, seller
                    contacts, and the
                    operational activity
                    across ReMarket.
                  </p>
                </div>

                {/* Notifications + Logout */}

                <div className="flex items-center justify-end gap-2">
                  <NotificationBell />

                  <button
                    type="button"
                    onClick={() => void handleLogout()}
                    className="
                      inline-flex
                      items-center
                      gap-2
                      rounded-xl
                      border
                      border-[#E8DED3]
                      bg-white
                      px-3
                      py-2
                      text-xs
                      font-semibold
                      text-[#6F675F]
                      transition
                      hover:border-[#D8C9BC]
                      hover:bg-[#FFF0E8]
                      hover:text-[#9F2D18]
                    "
                    aria-label="Log out"
                    title="Log out"
                  >
                    <LogOut className="h-4 w-4" />

                    <span className="hidden sm:inline">
                      Log out
                    </span>
                  </button>
                </div>
              </div>
            </div>

            {/* ERROR */}

            {error && (
              <div className="mb-6 rounded-2xl border border-[#F1C5BF] bg-[#FFF4F2] px-5 py-4">
                <p className="text-sm font-medium text-[#B42318]">
                  {error}
                </p>
              </div>
            )}

            {/* LOADING */}

            {loading ? (
              <div className="space-y-6">

                <div className="grid grid-cols-2 gap-4 xl:grid-cols-6">
                  {Array.from({ length: 6 }).map((_, index) => (
                    <div
                      key={index}
                      className="h-32 animate-pulse rounded-2xl border border-[#E8DED3] bg-white"
                    />
                  ))}
                </div>

                <div>
                  <div className="h-7 w-40 animate-pulse rounded bg-[#EAE3DC]" />

                  <div className="mt-4 grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">
                    {Array.from({ length: 5 }).map((_, index) => (
                      <div
                        key={index}
                        className="h-36 animate-pulse rounded-2xl border border-[#E8DED3] bg-white"
                      />
                    ))}
                  </div>
                </div>

                <div className="h-64 animate-pulse rounded-2xl border border-[#E8DED3] bg-white" />

                <div className="grid gap-6 xl:grid-cols-2">
                  <div className="h-80 animate-pulse rounded-2xl border border-[#E8DED3] bg-white" />

                  <div className="h-80 animate-pulse rounded-2xl border border-[#E8DED3] bg-white" />
                </div>
              </div>
            ) : data ? (
              <>

                {/* =================================================
                    STATISTICS
                ================================================= */}

                <section>
                  <div className="grid grid-cols-2 gap-4 xl:grid-cols-6">

                    <StatCard
                      label="Businesses"
                      value={data.stats.businesses}
                      icon={Store}
                      href="/admin/businesses"
                    />

                    <StatCard
                      label="Products"
                      value={data.stats.products}
                      icon={Package}
                      href="/admin/products"
                    />

                    <StatCard
                      label="Requests"
                      value={data.stats.requests}
                      icon={ClipboardList}
                      href="/admin/requests"
                    />

                    <StatCard
                      label="Matches"
                      value={data.stats.matches}
                      icon={Users}
                    />

                    <StatCard
                      label="Seller contacts"
                      value={data.stats.contacts}
                      icon={Contact}
                    />

                    <StatCard
                      label="Business views"
                      value={data.stats.businessViews}
                      icon={Eye}
                    />

                  </div>
                </section>

                {/* =================================================
                    PLATFORM OPERATIONS
                ================================================= */}

                <section className="mt-6">
                  <div className="mb-4">
                    <h2 className="text-lg font-semibold text-[#2E241F]">
                      Platform operations
                    </h2>

                    <p className="text-sm text-[#766C63]">
                      Current seller,
                      moderation, and
                      catalog activity
                      that may need
                      attention.
                    </p>
                  </div>

                  <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-5">

                    <OperationCard
                      label="Seller accounts"
                      value={data.operations.sellerAccounts}
                      description="Registered seller accounts"
                      icon={UserRound}
                    />

                    <OperationCard
                      label="Pending deletions"
                      value={data.operations.pendingDeletionRequests}
                      description="Business deletion requests awaiting review"
                      icon={Trash2}
                      href="/admin/business-deletion-requests"
                      attention={
                        data.operations.pendingDeletionRequests > 0
                      }
                    />

                    <OperationCard
                      label="Pending claims"
                      value={data.operations.pendingClaimRequests}
                      description="Business ownership claims awaiting review"
                      icon={AlertCircle}
                      href="/admin/claims"
                      attention={
                        data.operations.pendingClaimRequests > 0
                      }
                    />

                    <OperationCard
                      label="Categories"
                      value={data.operations.categories}
                      description={`${data.operations.activeCategories} active categories`}
                      icon={Tags}
                      href="/admin/categories"
                    />

                    <OperationCard
                      label="Active categories"
                      value={data.operations.activeCategories}
                      description="Categories currently available to the platform"
                      icon={Tags}
                      href="/admin/categories"
                    />

                  </div>
                </section>

                {/* =================================================
                    CONTACT ACTIVITY
                ================================================= */}

                <section className="mt-6">
                  <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                      <h2 className="text-lg font-semibold text-[#2E241F]">
                        Contact activity
                      </h2>

                      <p className="text-sm text-[#766C63]">
                        How buyers are
                        contacting sellers.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4 md:grid-cols-3 xl:grid-cols-6">

                    <ContactActivityCard
                      label="WhatsApp"
                      value={contactActivity.WHATSAPP}
                      icon={Contact}
                    />

                    <ContactActivityCard
                      label="Phone"
                      value={contactActivity.PHONE}
                      icon={Phone}
                    />

                    <ContactActivityCard
                      label="Instagram"
                      value={contactActivity.INSTAGRAM}
                      icon={ExternalLink}
                    />

                    <ContactActivityCard
                      label="TikTok"
                      value={contactActivity.TIKTOK}
                      icon={Contact}
                    />

                    <ContactActivityCard
                      label="Facebook"
                      value={contactActivity.FACEBOOK}
                      icon={ExternalLink}
                    />

                    <ContactActivityCard
                      label="Directions"
                      value={contactActivity.DIRECTIONS}
                      icon={MapPin}
                    />

                  </div>
                </section>

                {/* =================================================
                    RECENT DATA
                ================================================= */}

                <section className="mt-6 grid gap-6 xl:grid-cols-2">

                  {/* RECENT REQUESTS */}

                  <div className="rounded-2xl border border-[#E8DED3] bg-white">
                    <div className="flex items-center justify-between border-b border-[#E8DED3] px-5 py-4">
                      <div>
                        <h2 className="font-semibold text-[#2E241F]">
                          Recent requests
                        </h2>

                        <p className="mt-1 text-xs text-[#8B8178]">
                          Latest buyer requests
                        </p>
                      </div>

                      <Link
                        href="/admin/requests"
                        className="flex items-center gap-1 text-xs font-medium text-[#9F2D18] hover:underline"
                      >
                        View all
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    </div>

                    <div className="divide-y divide-[#E8DED3]">
                      {data.recentRequests.length === 0 ? (
                        <div className="px-5 py-10 text-center">
                          <ClipboardList className="mx-auto h-8 w-8 text-[#B8AEA5]" />

                          <p className="mt-3 text-sm font-medium text-[#6F675F]">
                            No requests yet
                          </p>
                        </div>
                      ) : (
                        data.recentRequests.map((request) => (
                          <div
                            key={request.id}
                            className="px-5 py-4"
                          >
                            <div className="flex items-start justify-between gap-4">
                              <div className="min-w-0">
                                <p className="truncate text-sm font-semibold text-[#2E241F]">
                                  {request.query}
                                </p>

                                <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-[#8B8178]">
                                  <span>
                                    {request.requestCode}
                                  </span>

                                  {request.category?.name && (
                                    <>
                                      <span>•</span>

                                      <span>
                                        {request.category.name}
                                      </span>
                                    </>
                                  )}

                                  <span>•</span>

                                  <span>
                                    {request.matchCount}{" "}
                                    {request.matchCount === 1
                                      ? "match"
                                      : "matches"}
                                  </span>
                                </div>
                              </div>

                              <span
                                className={`shrink-0 rounded-full px-2.5 py-1 text-[11px] font-semibold ${statusClass(
                                  request.status
                                )}`}
                              >
                                {request.status}
                              </span>
                            </div>

                            <p className="mt-2 text-xs text-[#9A9087]">
                              {formatDate(request.createdAt)}
                            </p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  {/* REGISTERED BUSINESSES */}

                  <div className="min-w-0 rounded-2xl border border-[#E8DED3] bg-white xl:col-span-1">
                    <div className="flex flex-col gap-3 border-b border-[#E8DED3] px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                      <div className="min-w-0">
                        <h2 className="font-semibold text-[#2E241F]">
                          Registered businesses
                        </h2>

                        <p className="mt-1 text-xs leading-5 text-[#8B8178]">
                          Browse all businesses registered on ReMarket, newest first.
                        </p>
                      </div>

                      <div className="flex shrink-0 items-center gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            setBusinessReloadKey((key) => key + 1)
                          }
                          disabled={businessDirectoryLoading}
                          className="inline-flex h-9 items-center justify-center gap-2 rounded-xl border border-[#E8DED3] bg-white px-3 text-xs font-semibold text-[#6F675F] transition hover:bg-[#FFF0E8] hover:text-[#9F2D18] disabled:cursor-not-allowed disabled:opacity-60"
                        >
                          <RefreshCw
                            className={`h-3.5 w-3.5 ${
                              businessDirectoryLoading
                                ? "animate-spin"
                                : ""
                            }`}
                          />

                          Refresh
                        </button>

                        <Link
                          href="/admin/businesses"
                          className="inline-flex h-9 items-center gap-1 rounded-xl bg-[#FFF0E8] px-3 text-xs font-semibold text-[#9F2D18] hover:bg-[#FFE3D7]"
                        >
                          Manage all
                          <ArrowRight className="h-3.5 w-3.5" />
                        </Link>
                      </div>
                    </div>

                    {businessDirectoryLoading ? (
                      <div
                        className="space-y-3 p-4 sm:p-5"
                        aria-label="Loading registered businesses"
                      >
                        {Array.from({ length: 4 }).map((_, index) => (
                          <div
                            key={index}
                            className="h-[68px] animate-pulse rounded-xl bg-[#F7F1EB]"
                          />
                        ))}
                      </div>
                    ) : businessDirectoryError ? (
                      <div className="p-5">
                        <div className="rounded-xl border border-[#F1C5BF] bg-[#FFF4F2] p-4">
                          <p className="text-sm font-semibold text-[#B42318]">
                            Unable to load the business directory
                          </p>

                          <p className="mt-1 text-xs leading-5 text-[#8B8178]">
                            {businessDirectoryError}
                          </p>

                          <button
                            type="button"
                            onClick={() =>
                              setBusinessReloadKey((key) => key + 1)
                            }
                            className="mt-3 inline-flex items-center gap-2 rounded-lg bg-white px-3 py-2 text-xs font-semibold text-[#9F2D18] ring-1 ring-[#F1C5BF] hover:bg-[#FFF0E8]"
                          >
                            <RefreshCw className="h-3.5 w-3.5" />
                            Try again
                          </button>
                        </div>
                      </div>
                    ) : registeredBusinesses.length === 0 ? (
                      <div className="px-5 py-10 text-center">
                        <Store className="mx-auto h-8 w-8 text-[#B8AEA5]" />

                        <p className="mt-3 text-sm font-medium text-[#6F675F]">
                          No registered businesses yet
                        </p>

                        <p className="mt-1 text-xs leading-5 text-[#8B8178]">
                          Businesses will appear here after they are registered.
                        </p>
                      </div>
                    ) : (
                      <>
                        <div className="divide-y divide-[#E8DED3]">
                          {pagedRegisteredBusinesses.map((business) => (
                            <div
                              key={business.id}
                              className="min-w-0 px-4 py-4 sm:px-5"
                            >
                              <div className="flex min-w-0 items-start justify-between gap-3">
                                <div className="min-w-0 flex-1">
                                  <Link
                                    href={`/admin/businesses/${encodeURIComponent(
                                      business.id
                                    )}`}
                                    className="block truncate text-sm font-semibold text-[#2E241F] hover:text-[#9F2D18] hover:underline"
                                    title={business.name}
                                  >
                                    {business.name}
                                  </Link>

                                  <p className="mt-1 truncate text-xs text-[#8B8178]">
                                    {business.area || "Area not provided"}

                                    <span className="px-1.5">
                                      ·
                                    </span>

                                    {formatDate(business.onboardedAt)}
                                  </p>
                                </div>

                                <Link
                                  href={`/admin/businesses/${encodeURIComponent(
                                    business.id
                                  )}`}
                                  aria-label={`View ${business.name}`}
                                  title="View business"
                                  className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[#E8DED3] text-[#6F675F] hover:border-[#D8C9BC] hover:bg-[#FFF0E8] hover:text-[#9F2D18]"
                                >
                                  <ExternalLink className="h-3.5 w-3.5" />
                                </Link>
                              </div>

                              <div className="mt-2 flex flex-wrap items-center gap-1.5">
                                <span
                                  className={`rounded-full px-2 py-1 text-[10px] font-semibold ${verificationClass(
                                    business.verification
                                  )}`}
                                >
                                  {business.verification}
                                </span>

                                <span
                                  className={`rounded-full px-2 py-1 text-[10px] font-semibold ${businessStatusClass(
                                    business.status
                                  )}`}
                                >
                                  {business.status}
                                </span>

                                {business.deletedAt && (
                                  <span className="rounded-full bg-[#FCE8E6] px-2 py-1 text-[10px] font-semibold text-[#B42318]">
                                    Deleted
                                  </span>
                                )}
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* BUSINESS DIRECTORY PAGINATION */}

                        <div className="flex flex-col gap-3 border-t border-[#E8DED3] px-4 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-5">
                          <p
                            className="text-xs text-[#8B8178]"
                            aria-live="polite"
                          >
                            Showing{" "}
                            {businessStartIndex === 0 &&
                            businessDirectoryTotal === 0
                              ? 0
                              : businessStartIndex + 1}
                            –{businessEndIndex} of{" "}
                            {businessDirectoryTotal} businesses
                          </p>

                          <div className="flex items-center justify-between gap-2 sm:justify-end">
                            <button
                              type="button"
                              onClick={() =>
                                setBusinessPage((page) =>
                                  Math.max(1, page - 1)
                                )
                              }
                              disabled={safeBusinessPage <= 1}
                              className="inline-flex h-9 items-center gap-1 rounded-xl border border-[#E8DED3] bg-white px-3 text-xs font-semibold text-[#6F675F] transition hover:bg-[#FFF0E8] hover:text-[#9F2D18] disabled:cursor-not-allowed disabled:opacity-40"
                            >
                              <ChevronLeft className="h-4 w-4" />
                              Previous
                            </button>

                            <span className="whitespace-nowrap text-xs font-semibold tabular-nums text-[#6F675F]">
                              Page {safeBusinessPage} of{" "}
                              {businessTotalPages}
                            </span>

                            <button
                              type="button"
                              onClick={() =>
                                setBusinessPage((page) =>
                                  Math.min(
                                    businessTotalPages,
                                    page + 1
                                  )
                                )
                              }
                              disabled={
                                safeBusinessPage >= businessTotalPages
                              }
                              className="inline-flex h-9 items-center gap-1 rounded-xl border border-[#E8DED3] bg-white px-3 text-xs font-semibold text-[#6F675F] transition hover:bg-[#FFF0E8] hover:text-[#9F2D18] disabled:cursor-not-allowed disabled:opacity-40"
                            >
                              Next
                              <ChevronRight className="h-4 w-4" />
                            </button>
                          </div>
                        </div>
                      </>
                    )}
                  </div>

                </section>
              </>
            ) : null}
          </div>
        </main>
      </div>

      {/* =====================================================
          MOBILE ADMIN NAVIGATION
      ===================================================== */}

      <nav
        className="fixed inset-x-0 bottom-0 z-50 border-t border-[#E8DED3] bg-[#FFFDFC]/95 px-2 pt-2 pb-[max(8px,env(safe-area-inset-bottom))] shadow-[0_-4px_18px_rgba(46,36,31,0.08)] backdrop-blur lg:hidden"
        aria-label="Mobile admin navigation"
      >
        <div className="mx-auto grid w-full max-w-3xl grid-cols-4 gap-1">
          {ADMIN_NAV.map((item) => {
            const Icon = item.icon;

            const active =
              item.href === "/admin"
                ? pathname === "/admin"
                : pathname === item.href ||
                  pathname.startsWith(`${item.href}/`);

            return (
              <Link
                key={item.href}
                href={item.href}
                aria-current={active ? "page" : undefined}
                className={`flex min-h-[48px] flex-col items-center justify-center gap-1 rounded-xl px-1 py-1 text-center text-[10px] font-semibold transition ${
                  active
                    ? "bg-[#FFF0E8] text-[#9F2D18]"
                    : "text-[#6F675F] hover:bg-[#F7F1EB]"
                }`}
              >
                <Icon className="h-4 w-4 shrink-0" />

                <span className="leading-tight">
                  {item.label}
                </span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
